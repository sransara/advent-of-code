
pub fn part1(inp: String) {
    println!("{}", inp.chars().rev().collect::<String>());
}
